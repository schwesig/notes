- https://github.com/schwesig/notes/blob/main/ROCE2025/jonathan-help-call.md
- https://grafana.apps.obs.nerc.mghpcc.org/dashboards/f/cejv67drt8q9sa/roce-2025-04

